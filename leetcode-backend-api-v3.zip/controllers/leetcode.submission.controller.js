import { fetchDailyChallenge } from '../services/leetcode.service.js';
import { submitSolution } from '../services/leetcode.submission.service.js';

export const submitDailySolution = async (req, res) => {
  try {
    console.log('Request body:', JSON.stringify(req.body, null, 2));
    
    // Extract and log headers for debugging
    const csrfToken = req.headers['x-csrftoken'];
    const cookiePresent = !!req.headers.cookie;
    const cookieLength = req.headers.cookie ? req.headers.cookie.length : 0;
    
    console.log('Submission request headers:', JSON.stringify({
      'Content-Type': req.headers['content-type'],
      'User-Agent': req.headers['user-agent'] ? 'User agent present' : 'User agent missing',
      'x-csrftoken': csrfToken ? 'CSRF token present' : 'CSRF token missing',
      'Cookie': cookiePresent ? `Cookie present (length: ${cookieLength})` : 'Cookie missing',
      'Origin': req.headers.origin,
      'Referer': req.headers.referer
    }, null, 2));

    // First, get the daily challenge to get the titleSlug
    const dailyChallenge = await fetchDailyChallenge();
    const { titleSlug } = dailyChallenge;
    console.log('Daily challenge titleSlug:', titleSlug);

    // Extract CSRF token from cookie if not in headers
    let extractedCsrfToken = csrfToken;
    if (!extractedCsrfToken && req.headers.cookie) {
      const csrfCookie = req.headers.cookie.split(';').find(c => c.trim().startsWith('csrftoken='));
      if (csrfCookie) {
        extractedCsrfToken = csrfCookie.split('=')[1].trim();
        console.log('Extracted CSRF token from cookie:', extractedCsrfToken);
      }
    }

    // Create headers object for the API call
    const headers = {
      cookie: req.headers.cookie,
      userAgent: req.headers['user-agent'],
      csrfToken: extractedCsrfToken,
      origin: req.headers.origin || 'https://leetcode.com',
      referer: req.headers.referer || 'https://leetcode.com/problems/'
    };

    console.log('Sending headers to service:', JSON.stringify({
      userAgent: headers.userAgent ? 'User agent present' : 'User agent missing',
      csrfToken: headers.csrfToken ? 'CSRF token present' : 'CSRF token missing',
      cookie: headers.cookie ? `Cookie present (length: ${headers.cookie.length})` : 'Cookie missing',
      origin: headers.origin,
      referer: headers.referer
    }, null, 2));

    // Submit the solution
    const submissionResult = await submitSolution(titleSlug, req.body, headers);
    console.log('Submission result:', JSON.stringify(submissionResult, null, 2));
    
    res.json(submissionResult);
  } catch (error) {
    console.error('Error in submitDailySolution controller:', error);
    let errorMessage = 'Failed to submit solution';
    let statusCode = 500;
    
    if (error.response) {
      statusCode = error.response.status;
      errorMessage += ` (Status: ${statusCode})`;
      console.error('Response data:', JSON.stringify(error.response.data, null, 2));
      
      // Check for CSRF verification failure
      if (error.response.data && error.response.data.includes('CSRF verification failed')) {
        errorMessage = 'CSRF verification failed. Please ensure your browser has cookies enabled.';
        console.error('CSRF verification failed. Request headers:', JSON.stringify({
          'x-csrftoken': req.headers['x-csrftoken'] || 'missing',
          'Origin': 'https://leetcode.com',
          'Referer': 'https://leetcode.com/'
        }, null, 2));
      }
    }
    
    res.status(statusCode).json({ error: errorMessage });
  }
};

export const submitDailySolutionAsProxy = async (req, res) => {
  try {
    // Extract the payload and headers from the request
    const { leetcodePayload, headers: clientHeaders } = req.body;
    
    console.log('Proxy submission request received');
    console.log('LeetCode payload:', JSON.stringify(leetcodePayload));
    console.log('Client headers:', JSON.stringify({
      'x-csrftoken': clientHeaders['x-csrftoken'] ? 'CSRF token present' : 'CSRF token missing',
      'Cookie': clientHeaders.Cookie ? `Cookie present (length: ${clientHeaders.Cookie.length})` : 'Cookie missing',
      'Origin': clientHeaders.Origin,
      'Referer': clientHeaders.Referer
    }, null, 2));
    
    // First, get the daily challenge to get the titleSlug
    const dailyChallenge = await fetchDailyChallenge();
    const { titleSlug } = dailyChallenge;
    console.log('Daily challenge titleSlug:', titleSlug);

    // Process headers for direct use with axios
    const axiosHeaders = {
      'Content-Type': 'application/json',
      'Cookie': clientHeaders.Cookie,
      'User-Agent': clientHeaders['User-Agent'],
      'x-csrftoken': clientHeaders['x-csrftoken'],
      'Origin': clientHeaders.Origin,
      'Referer': clientHeaders.Referer,
      'Host': 'leetcode.com'
    };

    // Make direct request to LeetCode API
    const axios = (await import('axios')).default;
    const submissionUrl = `https://leetcode.com/problems/${titleSlug}/submit/`;
    
    console.log('Making direct request to LeetCode API:', submissionUrl);
    
    try {
      const response = await axios.post(submissionUrl, leetcodePayload, {
        headers: axiosHeaders
      });
      
      console.log('Direct submission successful:', response.status);
      console.log('Response data:', JSON.stringify(response.data, null, 2));
      
      res.json(response.data);
    } catch (apiError) {
      console.error('LeetCode API error:', apiError.message);
      
      if (apiError.response) {
        const statusCode = apiError.response.status;
        console.error('API response status:', statusCode);
        console.error('API response data:', JSON.stringify(apiError.response.data, null, 2));
        
        res.status(statusCode).json({ 
          error: apiError.response.data?.error || 'LeetCode API error',
          details: apiError.response.data
        });
      } else {
        res.status(500).json({ error: 'Failed to submit to LeetCode API: ' + apiError.message });
      }
    }
  } catch (error) {
    console.error('Error in proxy submission:', error);
    res.status(500).json({ error: 'Failed to process submission request' });
  }
};