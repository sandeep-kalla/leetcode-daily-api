import { checkSubmissionStatus } from '../services/leetcode.check.service.js';

export const checkSubmission = async (req, res) => {
  try {
    const { submissionId } = req.params;

    // Extract required headers from request
    const headers = {
      cookie: req.headers.cookie,
      userAgent: req.headers['user-agent'],
      csrfToken: req.headers['x-csrftoken']
    };

    // Check submission status
    const result = await checkSubmissionStatus(submissionId, headers);
    
    res.json(result);
  } catch (error) {
    console.error('Error in checkSubmission controller:', error);
    res.status(500).json({ error: 'Failed to check submission status' });
  }
};

export const checkSubmissionAsProxy = async (req, res) => {
  try {
    // Extract the submission ID and headers from the request
    const { submissionId, headers: clientHeaders } = req.body;
    
    console.log('Proxy status check request received for submission ID:', submissionId);
    console.log('Client headers:', JSON.stringify({
      'x-csrftoken': clientHeaders['x-csrftoken'] ? 'CSRF token present' : 'CSRF token missing',
      'Cookie': clientHeaders.Cookie ? `Cookie present (length: ${clientHeaders.Cookie.length})` : 'Cookie missing',
      'Origin': clientHeaders.Origin,
      'Referer': clientHeaders.Referer
    }, null, 2));
    
    // Process headers for direct use with axios
    const axiosHeaders = {
      'Content-Type': 'application/json',
      'Cookie': clientHeaders.Cookie,
      'User-Agent': clientHeaders['User-Agent'],
      'x-csrftoken': clientHeaders['x-csrftoken'],
      'Origin': clientHeaders.Origin,
      'Referer': clientHeaders.Referer,
      'Host': 'leetcode.com'
    };

    // Make direct request to LeetCode API
    const axios = (await import('axios')).default;
    const checkUrl = `https://leetcode.com/submissions/detail/${submissionId}/check/`;
    
    console.log('Making direct request to LeetCode API for status check:', checkUrl);
    
    try {
      const response = await axios.get(checkUrl, {
        headers: axiosHeaders
      });
      
      console.log('Status check successful:', response.status);
      console.log('Response data:', JSON.stringify(response.data, null, 2));
      
      res.json(response.data);
    } catch (apiError) {
      console.error('LeetCode API error during status check:', apiError.message);
      
      if (apiError.response) {
        const statusCode = apiError.response.status;
        console.error('API response status:', statusCode);
        console.error('API response data:', JSON.stringify(apiError.response.data, null, 2));
        
        res.status(statusCode).json({ 
          error: apiError.response.data?.error || 'LeetCode API error during status check',
          details: apiError.response.data
        });
      } else {
        res.status(500).json({ error: 'Failed to check status with LeetCode API: ' + apiError.message });
      }
    }
  } catch (error) {
    console.error('Error in proxy status check:', error);
    res.status(500).json({ error: 'Failed to process status check request' });
  }
};